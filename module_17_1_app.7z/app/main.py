import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from routers import task, task1, user1
from fastapi import  status, Body, HTTPException
from pydantic import BaseModel
from typing import List
from fastapi.templating import Jinja2Templates

templates = Jinja2Templates(directory='templates')

app = FastAPI()

messages_db = []


class Message(BaseModel):
    id: int = None
    text: str

@app.get("/")
async def welcome():
    return {"message": "Welcome to Taskmanager Task__1"}
def get_all_messages() -> List[Message]:
    return messages_db


@app.get(path="/message/{message_id}")
def get_message(request: Request, user_id: int) -> HTMLResponse:
    try:
        return templates.TemplateResponse('users.html', {'request': request, 'users': users})
        #return messages_db[message_id]
    except IndexError:
        raise HTTPException(status_code=404, detail="Message not found")
@app.post("/message")


def create_message(message: Message) -> str:
    message.id = len(messages_db)
    messages_db.append(message)
    return f"Message created!"


@app.put("/message/{message_id}")
def update_message(message_id: int, message: str = Body()) -> str:
    try:
        edit_message = messages_db[message_id]
        edit_message.text = message
        return f"Message updated!"
    except IndexError:
        raise HTTPException(status_code=404, detail="Message not found")


app.include_router(task.router)
app.include_router(task1.router)
app.include_router(user1.router)




