# Задача "Основные маршруты":

from fastapi import APIRouter


router = APIRouter(prefix="/task", tags=["task"])

@router.get("/")
async def all_tasks():
    return {"message": "Welcome to Taskmanager all_tasks"}


@router.get("/task_id")
async def task_by_id():
    return {"message": "Welcome to Taskmanager task_id"}

@router.get("/create")
async def task_by_id():
    return {"message": "Welcome to Taskmanager create"}


@router.post("/create")
async def create_task():
    return {"message": "Welcome to Taskmanager1 create"}


@router.put("/update")
async def update_task():
    pass
@router.delete("/delete")
async def delete_task():
    pass
