# Задача "Основные маршруты":

from fastapi import APIRouter

router = APIRouter(prefix="/task1", tags=["task1"])

@router.get("/")
async def all_users():
    return {"message": "Welcome to Taskmanager all_tasks1"}
    pass
@router.get("/user_id")
async def user_by_id():
    pass
@router.post("/create")
async def create_user():
    return {"message": "Welcome to Taskmanager1 post create1"}
    pass
@router.put("/update")
async def update_user():
    return {"message": "Welcome to Taskmanager1 update1"}
    pass
@router.delete("/delete")
async def delete_user():
    pass
