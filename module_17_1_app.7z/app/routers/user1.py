# Задача "Основные маршруты":

from fastapi import APIRouter

router = APIRouter(prefix="/user1", tags=["user1"])

@router.get("/")
async def all_users():
    pass
@router.get("/user_id")
async def user_by_id():
    pass
@router.post("/create")
async def create_user():
    return {"message": "Welcome to Taskmanager1 user1 post create"}

@router.put("/update")
async def update_user():
    pass